// src/pages/notice/NoticeList.js

import React from 'react';

function NoticeList() {
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h2>공지사항 목록</h2>
      <p>여기에 공지사항 목록이 표시될 예정입니다.</p>
      {/* 실제 공지사항 데이터와 렌더링 로직이 들어갈 곳 */}
    </div>
  );
}

export default NoticeList;
